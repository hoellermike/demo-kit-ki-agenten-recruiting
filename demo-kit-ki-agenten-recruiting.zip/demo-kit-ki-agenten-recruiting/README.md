# Demo-Kit: KI-Agenten im Recruiting

Das ist der Recruiting-Agent aus dem Vortrag „KI-Agenten im Recruiting“ (Digitalks Neunkirchen, 15. September 2026, Michael Höller, marketingwerk). Ein Agent, der eine offene Stelle von der Sprachnachricht des Chefs bis zur laufenden Kampagne übernimmt, und dabei keinen einzigen Bewerber bewertet.

Alles in diesem Kit ist erfunden: die Firma Wimmer Metalltechnik, die Personen, die Telefonnummern, die Bewerbungen. Das Kit ist zum Nachbauen und Lernen gedacht, kein Produkt und keine Rechtsberatung.

## Was drin ist

| Ordner | Inhalt |
|---|---|
| `recruiting-agent/` | Der Agent im Ausgangszustand. Die Arbeitsanweisung (`AGENTS.md`, identisch als `CLAUDE.md` und `GEMINI.md`), die drei Prompts (`PROMPT.md`), der Auftrag des Chefs, das Firmenprofil, die Kanalübersicht, die Budgetregeln. |
| `beispiel-ergebnisse/` | Was der Agent bei uns in Phase 1 und 2 erzeugt hat: Marktcheck, Stellenprofil, die drei Rückfragen samt Antworten, vier Kanaltexte, Kampagnen-Setup, Freigabe, Protokoll. Zum Vergleichen, nicht zum Kopieren. |
| `beispiel-bewerbungen/` | Sieben fiktive Bewerbungen für Phase 3. Eine davon legen Sie während des Laufs in den Eingang. |

## Was Sie brauchen

Ein KI-Werkzeug, das drei Dinge kann: Dateien in einem Ordner lesen und schreiben, im Web suchen, und mehrere Schritte selbständig hintereinander ausführen. Das ist der Unterschied zwischen einem Chat und einem Agenten. Drei Werkzeuge sind erprobt, alle drei lesen die Arbeitsanweisung im Ordner automatisch:

| Werkzeug | Anbieter | Liest | Installation |
|---|---|---|---|
| Codex (App oder Terminal) | OpenAI | `AGENTS.md` | App: chatgpt.com/codex · Terminal: `npm install -g @openai/codex` |
| Claude Code | Anthropic | `CLAUDE.md` | claude.com/claude-code · Terminal: `npm install -g @anthropic-ai/claude-code` |
| Gemini CLI | Google | `GEMINI.md` | `npm install -g @google/gemini-cli` |

Sie brauchen ein Konto beim jeweiligen Anbieter, meist mit Bezahlplan (zweistelliger Betrag im Monat). Für die Terminal-Varianten muss Node.js installiert sein (nodejs.org). Programmieren müssen Sie nicht.

## In 20 Minuten nachbauen

### Schritt 1: Ordner öffnen

- **Codex App:** Projekt hinzufügen, den Ordner `recruiting-agent` wählen. Modell mit hoher Denkstufe, Websuche an, Berechtigung auf „Uneingeschränkter Zugriff“ (sonst fragt er bei jeder Datei nach).
- **Codex Terminal:** `cd` in den Ordner `recruiting-agent`, dann `codex --full-auto --search`.
- **Claude Code:** `cd` in den Ordner `recruiting-agent`, dann `claude`. Mit Umschalt+Tab auf „accept edits“ stellen, damit er Dateien ohne Rückfrage schreibt. Websuche ist eingebaut.
- **Gemini CLI:** `cd` in den Ordner `recruiting-agent`, dann `gemini --yolo`. Websuche ist eingebaut.

Wenn Sie ein anderes Werkzeug verwenden: Es muss die Datei `AGENTS.md` als Arbeitsanweisung lesen. Notfalls den Inhalt als erste Nachricht einfügen.

### Schritt 2: Die drei Phasen

Die Prompts stehen in `recruiting-agent/PROMPT.md`. Kurz:

1. **Auftrag.** Sie tippen einen Satz. Der Agent recherchiert den Markt, schreibt ein Stellenprofil und stellt drei Rückfragen. Sie beantworten die Fragen in der Datei.
2. **Anzeige und Kampagne.** Sie tippen einen Satz. Der Agent schreibt die Anzeige, wählt die Kanäle, setzt die Kampagne auf und legt alles zur Freigabe vor. Sie tragen die Freigabe in der Datei ein.
3. **Betrieb.** Sie tippen einen Satz, legen eine Bewerbung in den Eingang und schauen zu. Der Agent bestätigt, legt ab, meldet. Bewerten tut er nicht.

Rechnen Sie mit zwei bis fünf Minuten pro Phase, je nach Werkzeug. Der Agent „veröffentlicht“ nur in Dateien innerhalb des Ordners. Es geht nichts online, es wird kein Geld ausgegeben.

### Schritt 3: Auf den eigenen Betrieb übertragen

Vier Dateien anpassen, sonst nichts:

- `firma/firmenprofil.md`: Ihr Betrieb, Ihre Konditionen, Ihre offene Stelle.
- `systeme/plattformen.md`: Welche Kanäle Sie wirklich haben und was sie kosten.
- `systeme/budget.md`: Was der Agent ohne Rückfrage darf.
- `auftrag.md`: Was Sie ihm sagen würden, in zwei Sätzen.

Die Arbeitsanweisung `AGENTS.md` bleibt zunächst unverändert. Erst wenn Sie zehn Läufe gesehen haben, wissen Sie, was Sie ändern wollen.

## Die Grenze

Der Agent liest keine Lebensläufe, erstellt keine Rangliste und sagt nie, wer besser ist. Das ist keine technische Grenze, sondern eine Entscheidung. Bewerberauswahl durch KI gilt nach dem EU AI Act als Hochrisiko-Anwendung: Ein Mensch muss beaufsichtigen, und Sie müssen es belegen können. Deshalb führt der Agent ein Protokoll (`protokoll/lauf.md`), holt Freigaben ein und legt Ihnen Menschen vor, statt über sie zu urteilen. Wenn Sie die Anweisung ändern, behalten Sie diese vier Punkte bei: Protokoll, Freigabe, keine Bewertung, kein erfundenes Gehalt.

## Womit Sie anfangen sollten

Nicht mit dem Recruiting. Mit der langweiligsten Aufgabe, die Sie haben. Eine Seite Anweisung schreiben, wie für einen neuen Mitarbeiter. Zehn Fälle prüfen. Dann loslassen.

## Fragen

Michael Höller, marketingwerk, Pitten und Wien
michael@marketingwerk.at · marketingwerk.at
30 Minuten Arbeitsgespräch: calendly.com/marketingwerk-at/30min
