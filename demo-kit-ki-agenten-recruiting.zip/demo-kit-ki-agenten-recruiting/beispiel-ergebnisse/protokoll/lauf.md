2026-09-15T12:56:33+02:00 | Auftrag, Firmenprofil, Plattformen, Budgetrahmen und Arbeitsregeln gelesen; gesucht wird CNC-Fräsen mit Heidenhain oder Siemens und Zweischicht.
2026-09-15T12:56:33+02:00 | Phase 1 begonnen; regionale Stellenangebote und Entlohnung werden geprüft. Gehaltsband, Arbeitszeiten und Abgrenzung der offenen Stelle sind noch zu klären.
2026-09-15T12:58:03+02:00 | Regionale Webrecherche abgeschlossen: Trenkwalder in Ternitz, staff24 in Wiener Neustadt-Land und Kernbeis in Wöllersdorf geprüft; Inseratsbeträge und Konditionen mit Quellen erfasst.
2026-09-15T12:58:03+02:00 | WKO-Lohnordnung Metallgewerbe 2026 und AMS JobBarometer geprüft; Mindestlohn von tatsächlichem Angebot und Inseratsnachfrage von verfügbaren Fachkräften getrennt. Abgelaufenes willhaben-Inserat nicht als aktive Konkurrenz übernommen.
2026-09-15T12:58:03+02:00 | systeme/berichte/marktcheck.md erstellt: Marktvergleich, Quellen und Einordnung dokumentiert.
2026-09-15T12:58:03+02:00 | systeme/berichte/stellenprofil.md erstellt: Aufgaben sowie Muss- und Kann-Kriterien formuliert.
2026-09-15T12:58:03+02:00 | freigaben/01-rueckfragen.md erstellt: Drei gebündelte Rückfragen zu Gehalt, Arbeitszeit und Besetzungsbedarf abgelegt.
2026-09-15T12:58:03+02:00 | systeme/berichte/phase-1.md erstellt: Phasenbericht erstellt; Phase 2 wartet auf Antworten des Chefs.
2026-09-15T12:58:15+02:00 | Abschlusskontrolle: Marktquellen, Stellenprofil, drei Rückfragen und Phasenbericht gespeichert; keine Kanaltexte veröffentlicht und keine Ausgaben veranlasst.
2026-09-15T13:00:11+02:00 | Antworten des Chefs vom 15.09.2026 gelesen: eine Direktanstellung, Gehaltsband 3.500–4.100 € plus KV-Zulagen, Freitag ab 12:00 frei, keine 4-Tage-Woche; Phase 2 begonnen.
2026-09-15T13:02:45+02:00 | WKO-Mindestlohn und Inseratspflichten erneut geprüft; Facharbeiter-Gruppe laut Chef als Lohngruppe 3 zugeordnet. Meta-Zielgruppe ohne Einschränkung nach Alter oder Geschlecht geplant.
2026-09-15T13:02:45+02:00 | Rückfragenstatus auf beantwortet gesetzt; Antworten des Chefs unverändert erhalten.
2026-09-15T13:02:45+02:00 | Vollfassung und öffentlicher Formulartext für die Karriereseite erstellt; Veröffentlichung ausständig | systeme/kanaele/karriereseite.md
2026-09-15T13:02:45+02:00 | AMS-Inserat mit Voraussetzungen, Zeiten und Entgelt erstellt; Veröffentlichung ausständig | systeme/kanaele/ams.md
2026-09-15T13:02:45+02:00 | Regionale Kurzfassung für willhaben erstellt; Veröffentlichung ausständig | systeme/kanaele/willhaben.md
2026-09-15T13:02:45+02:00 | Drei vollständige Meta-Anzeigenvarianten und Formulartext erstellt; Veröffentlichung ausständig | systeme/kanaele/meta.md
2026-09-15T13:02:45+02:00 | Kanalauswahl, Budget, Zielgruppe, Laufzeiten, drei Anzeigen und Motivvorschlag sowie Betrieb nach Freigabe festgelegt | systeme/kampagne/setup.md
2026-09-15T13:02:45+02:00 | Vollständiges Veröffentlichungspaket und 569 € Gesamtrahmen zur Freigabe abgelegt | freigaben/02-veroeffentlichung.md
2026-09-15T13:02:45+02:00 | Alle Kanäle ausdrücklich auf vorbereitet, nicht veröffentlicht gesetzt; Ausgaben 0 € | systeme/kampagne/status.md
2026-09-15T13:02:45+02:00 | Phasenbericht erstellt; Arbeit wartet auf Veröffentlichung und Budgetfreigabe | systeme/berichte/phase-2.md
2026-09-15T13:02:45+02:00 | Stellenprofil mit bestätigtem Bedarf, Arbeitszeiten und Gehaltsband aktualisiert | systeme/berichte/stellenprofil.md
2026-09-15T13:03:14+02:00 | Inhaltskontrolle aller Kanaltexte erfolgreich; technische Statusprüfung wegen zu enger Textsuche korrigiert, Inhalte unverändert.
2026-09-15T13:03:14+02:00 | Phase-2-Abschlusskontrolle bestanden: Entgelt und Zeiten in vier Kanaltexten konsistent; drei Meta-Varianten, 569 € Gesamtrahmen, Freigabe ausständig, keine Veröffentlichung und keine Ausgaben.
