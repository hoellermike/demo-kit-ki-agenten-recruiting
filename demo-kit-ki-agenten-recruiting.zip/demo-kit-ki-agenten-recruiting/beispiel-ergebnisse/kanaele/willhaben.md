# CNC-Fräser:in (m/w/d) – Freitag ab 12:00 frei

**Wimmer Metalltechnik GmbH · Ternitz · Direktanstellung · 38,5 Stunden**

Du arbeitest mit Heidenhain oder Siemens? Bei Wimmer fertigst du Einzelteile und Kleinserien an CNC-Fräsmaschinen. Freitags beginnt dein Wochenende um 12:00 Uhr – auch in der Spätschichtwoche.

**3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.**

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

**Deine Zeiten:** Montag bis Donnerstag 06:00–14:30 oder 14:00–22:30 Uhr im Früh-/Spätwechsel. Freitag nur Frühschicht bis 12:00 Uhr.

**Deine Arbeit:** Maschinen einrichten und programmieren, nach Zeichnung fräsen und Werkstücke prüfen.

**Das brauchst du:** abgeschlossene Ausbildung in Zerspanungstechnik, Maschinenbautechnik oder vergleichbar, mindestens zwei Jahre CNC-Fräserfahrung, Heidenhain- oder Siemens-Programmierkenntnisse und Bereitschaft zur Zweischicht. Deutsch für Arbeitsanweisungen und Zeichnungen, mindestens B1.

5-Achs-, CAM- und vertiefte Messtechnikkenntnisse sowie Staplerschein sind willkommen, aber nicht erforderlich.

**Das kommt dazu:** Steuerungs- und CAM-Weiterbildung, Mittagessen-Zuschuss und Parkplatz. Du wirst direkt bei unserem Familienbetrieb angestellt.

Arbeitsort: Werkstraße 14, 2630 Ternitz. Start ab sofort oder nach Vereinbarung – auch mit drei Monaten Kündigungsfrist.

**Jetzt über die Bewerbungsfunktion melden.** Name und Telefonnummer oder E-Mail-Adresse reichen für den ersten Kontakt. Ein Lebenslauf ist dafür nicht nötig. Ansprechperson: Gerhard Wimmer.
