# Zerspanungstechniker:in CNC-Fräsen (m/w/d)

Wimmer Metalltechnik GmbH sucht eine Fachkraft für CNC-Fräsen in Ternitz. Vollzeit, 38,5 Stunden pro Woche, direkte Anstellung im Betrieb.

**Freitag ab 12:00 Uhr frei – in beiden Schichtwochen.**

## Entlohnung

3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

## Tätigkeit und Voraussetzungen

Du richtest CNC-Fräsmaschinen ein, programmierst mit Heidenhain oder Siemens, fertigst Einzelteile und Kleinserien nach Zeichnung und prüfst deine Werkstücke.

Du hast eine abgeschlossene Ausbildung in Zerspanungstechnik, Maschinenbautechnik oder einem vergleichbaren Bereich und mindestens zwei Jahre CNC-Fräserfahrung. Heidenhain- oder Siemens-Programmierkenntnisse sowie Bereitschaft zur Zweischicht sind erforderlich. Du verstehst Arbeitsanweisungen und Zeichnungen auf Deutsch, mindestens B1.

5-Achs-Erfahrung, CAM-Kenntnisse, vertiefte Messtechnik und Staplerschein sind von Vorteil, aber keine Voraussetzung.

## Arbeitszeiten und Angebot

Montag bis Donnerstag Frühschicht 06:00–14:30 Uhr oder Spätschicht 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr, auch in der Spätschichtwoche.

Dazu kommen Steuerungs- und CAM-Weiterbildung, Mittagessen-Zuschuss und Firmenparkplatz. Wir sind ein Familienbetrieb mit 38 Mitarbeiter:innen.

Arbeitsort: Werkstraße 14, 2630 Ternitz. Beginn ab sofort oder nach Vereinbarung; auch drei Monate Kündigungsfrist sind möglich.

## Bewerbung

Nutze die Bewerbungsfunktion dieser Anzeige. Für den ersten Kontakt genügen Name und Telefonnummer oder E-Mail-Adresse. Ein Lebenslauf ist dafür nicht nötig. Ansprechperson: Gerhard Wimmer, Wimmer Metalltechnik GmbH.
