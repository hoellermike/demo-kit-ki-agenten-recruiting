# CNC-Fräsen in Ternitz: Freitag ab 12:00 frei

## Zerspanungstechniker:in CNC-Fräsen (m/w/d)

**Wimmer Metalltechnik GmbH · Ternitz · Vollzeit · Direktanstellung**

Du programmierst CNC-Fräsmaschinen mit Heidenhain oder Siemens und möchtest vor dem Wechsel wissen, was dich erwartet? Bei Wimmer fertigst du Einzelteile und Kleinserien für Maschinenbau, Bahntechnik und Energieanlagen. Du arbeitest im Früh-/Spätwechsel. Freitags endet die Arbeit in beiden Schichtwochen um 12:00 Uhr.

### Dein Gehalt

**3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.**

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

### Deine Arbeitszeit

- 38,5 Stunden pro Woche.
- Montag bis Donnerstag: Frühschicht 06:00–14:30 Uhr oder Spätschicht 14:00–22:30 Uhr.
- Freitag: nur Frühschicht, Ende um 12:00 Uhr – auch in deiner Spätschichtwoche.
- Einstieg ab sofort oder nach Vereinbarung. Auch mit drei Monaten Kündigungsfrist kannst du dich bewerben.

### Deine Arbeit

Du richtest CNC-Fräsmaschinen ein, programmierst mit Heidenhain oder Siemens und fertigst nach Zeichnung. Du kontrollierst die Maße deiner Werkstücke und meldest Abweichungen. Im Betrieb arbeiten wir unter anderem mit DMG MORI, Hermle und Mazak sowie mit 3- und 5-Achs-Bearbeitung.

### Das bringst du mit

- Abgeschlossene Ausbildung in Zerspanungstechnik, Maschinenbautechnik oder einem vergleichbaren Bereich.
- Mindestens zwei Jahre Erfahrung an CNC-Fräsmaschinen.
- Programmierkenntnisse in Heidenhain oder Siemens.
- Bereitschaft zu Früh- und Spätschicht.
- Deutsch für Arbeitsanweisungen und Zeichnungen, mindestens B1.

5-Achs-Erfahrung, CAM-Kenntnisse, vertiefte Messtechnik oder ein Staplerschein sind willkommen, aber keine Voraussetzung.

### Was du bei Wimmer bekommst

- Direkte Anstellung bei einem Familienbetrieb mit 38 Mitarbeiter:innen.
- Weiterbildung in Steuerungen und CAM, der computergestützten Fertigungsprogrammierung.
- Zuschuss zum Mittagessen und Firmenparkplatz.
- Einen Arbeitsplatz in Ternitz, Werkstraße 14, 2630 Ternitz.

### Bewirb dich bei uns

Zum ersten Kontakt reichen dein Name und eine Telefonnummer oder E-Mail-Adresse. Ein Lebenslauf ist dafür nicht nötig. Ansprechperson ist Gerhard Wimmer.

**Schaltfläche: Jetzt bewerben**

### Bewerbungsformular

- Name (Pflichtfeld)
- Telefonnummer oder E-Mail-Adresse (mindestens eine Kontaktmöglichkeit erforderlich)
- Frühestmöglicher Start (freiwillig)
- Deine Nachricht an Gerhard Wimmer (freiwillig)

Deine Angaben verwenden wir zur Bearbeitung deiner Bewerbung bei Wimmer Metalltechnik GmbH.

**Schaltfläche: Bewerbung absenden**

Bestätigung nach dem Absenden: Danke, deine Bewerbung ist angekommen. Wir melden uns bei dir.
