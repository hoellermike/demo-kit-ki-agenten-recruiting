# Facebook und Instagram – Anzeigentexte

## Variante 1

### Haupttext

CNC-Fräsen in Ternitz: Bei Wimmer ist freitags um 12:00 Uhr Schluss – in beiden Schichtwochen. Montag bis Donnerstag arbeitest du im Früh-/Spätwechsel. Du fertigst Einzelteile und Kleinserien mit Heidenhain oder Siemens.

Zerspanungstechniker:in CNC-Fräsen (m/w/d) · Direktanstellung · 38,5 Stunden.

3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

Du brauchst eine einschlägige abgeschlossene Ausbildung, mindestens zwei Jahre CNC-Fräserfahrung und Programmierkenntnisse in Heidenhain oder Siemens. Deutsch für Arbeitsanweisungen und Zeichnungen: mindestens B1.

Montag bis Donnerstag: 06:00–14:30 oder 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr, in beiden Wochen. Start ab sofort oder nach Vereinbarung; auch drei Monate Kündigungsfrist sind möglich.

Melde dich mit Name und Telefonnummer oder E-Mail-Adresse. Ein Lebenslauf ist für den ersten Kontakt nicht nötig.

### Überschrift

Freitag ab 12:00 frei

### Beschreibung

CNC-Fräsen (m/w/d) · Wimmer Metalltechnik

### Schaltfläche

Jetzt bewerben

## Variante 2

### Haupttext

Wimmer Metalltechnik sucht eine CNC-Fräsfachkraft (m/w/d) in Ternitz. Du weißt vor dem Wechsel, welches Gehaltsband wir bieten. Du wirst direkt bei uns angestellt und kannst auch mit drei Monaten Kündigungsfrist einsteigen.

Zerspanungstechniker:in CNC-Fräsen (m/w/d) · Direktanstellung · 38,5 Stunden.

3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

Du brauchst eine einschlägige abgeschlossene Ausbildung, mindestens zwei Jahre CNC-Fräserfahrung und Programmierkenntnisse in Heidenhain oder Siemens. Deutsch für Arbeitsanweisungen und Zeichnungen: mindestens B1.

Montag bis Donnerstag: 06:00–14:30 oder 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr, in beiden Wochen. Start ab sofort oder nach Vereinbarung; auch drei Monate Kündigungsfrist sind möglich.

Melde dich mit Name und Telefonnummer oder E-Mail-Adresse. Ein Lebenslauf ist für den ersten Kontakt nicht nötig.

### Überschrift

3.500–4.100 € plus KV-Zulagen

### Beschreibung

CNC-Fräsen (m/w/d) · Wimmer Metalltechnik

### Schaltfläche

Jetzt bewerben

## Variante 3

### Haupttext

Bei Wimmer Metalltechnik in Ternitz arbeitest du an Einzelteilen und Kleinserien. Für unsere CNC-Frässtelle (m/w/d) bringst du Programmierkenntnisse in Heidenhain oder Siemens mit. Steuerungs- und CAM-Weiterbildung gehören zum Angebot.

Zerspanungstechniker:in CNC-Fräsen (m/w/d) · Direktanstellung · 38,5 Stunden.

3.500–4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulagen laut KV kommen zusätzlich dazu.

KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat bei Vollzeit (Stand 2026). Wir überzahlen den KV mit dem genannten Gehaltsband.

Du brauchst eine einschlägige abgeschlossene Ausbildung, mindestens zwei Jahre CNC-Fräserfahrung und Programmierkenntnisse in Heidenhain oder Siemens. Deutsch für Arbeitsanweisungen und Zeichnungen: mindestens B1.

Montag bis Donnerstag: 06:00–14:30 oder 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr, in beiden Wochen. Start ab sofort oder nach Vereinbarung; auch drei Monate Kündigungsfrist sind möglich.

Melde dich mit Name und Telefonnummer oder E-Mail-Adresse. Ein Lebenslauf ist für den ersten Kontakt nicht nötig.

### Überschrift

Heidenhain oder Siemens?

### Beschreibung

CNC-Fräsen (m/w/d) · Wimmer Metalltechnik

### Schaltfläche

Jetzt bewerben

## Gemeinsames Bewerbungsformular

### Überschrift

Deine Bewerbung bei Wimmer Metalltechnik

### Einleitung

CNC-Fräsen in Ternitz, 38,5 Stunden, Direktanstellung. 3.500–4.100 € brutto pro Monat nach Erfahrung plus KV-Schichtzulagen. KV-Mindestgrundlohn Metallgewerbe, Arbeiter:innen, Lohngruppe 3: 2.948,85 € brutto pro Monat (Vollzeit, Stand 2026); Überzahlung im genannten Band.

Montag bis Donnerstag Früh-/Spätwechsel: 06:00–14:30 oder 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr, auch in der Spätschichtwoche. Ansprechperson: Gerhard Wimmer.

### Felder

- Name (Pflichtfeld)
- Telefonnummer oder E-Mail-Adresse (mindestens eine Kontaktmöglichkeit erforderlich)
- Frühestmöglicher Start (freiwillig)
- Deine Nachricht an Gerhard Wimmer (freiwillig)

Deine Angaben verwenden wir zur Bearbeitung deiner Bewerbung bei Wimmer Metalltechnik GmbH.

### Schaltfläche

Bewerbung absenden

### Abschlussnachricht

Danke, deine Bewerbung ist angekommen. Wir melden uns bei dir.
