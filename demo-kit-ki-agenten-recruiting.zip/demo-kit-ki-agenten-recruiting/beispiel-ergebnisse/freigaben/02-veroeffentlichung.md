# Freigabe: Stellenanzeigen und Recruiting-Kampagne

Version 1 · 15. September 2026 · **Freigabe ausständig**

Gerhard, die Anzeigen sind fertig. Sie nennen dein Gehaltsband von **3.500–4.100 € brutto pro Monat bei 38,5 Stunden plus KV-Schichtzulagen** und stellen **Freitag ab 12:00 Uhr frei** heraus. Es geht um eine Direktanstellung; auch ein Einstieg nach drei Monaten Kündigungsfrist ist berücksichtigt. Die 4-Tage-Woche wird nicht angeboten.

## Was du freigeben sollst

| Bestandteil | Zur Prüfung | Kosten |
|---|---|---:|
| Vollständige Stellenanzeige und Bewerbungsformular auf der Karriereseite | `systeme/kanaele/karriereseite.md` | 0 € |
| AMS-Inserat | `systeme/kanaele/ams.md` | 0 € |
| willhaben-Inserat, 30 Tage | `systeme/kanaele/willhaben.md` | 149 € |
| Facebook-/Instagram-Kampagne, 21 Tage, gemeinsames Budget für alle Varianten | Drei vollständige Texte und Formular: `systeme/kanaele/meta.md`; Einstellungen: `systeme/kampagne/setup.md` | 420 € |
| Schriftmotiv: dunkelblau/weiß, orangefarbener Freitagsakzent; Rolle, Ort, Freitag, Gehaltsband, Stunden, Zulagen, Mindestlohn und Bewerbungshinweis | Exakter Motivtext und Gestaltung im Abschnitt „Motivvorschlag zur Freigabe“ in `systeme/kampagne/setup.md` | Keine zusätzlichen Kosten vorgesehen |
| **Gesamtrahmen** | **Einmalig, keine automatische Verlängerung** | **569 €** |

Die Beträge beruhen auf unserer Plattformübersicht. Der Meta-Anteil entspricht im Durchschnitt 20 € täglich; das Gesamtlimit beträgt 420 €, nicht 420 € je Anzeige. karriere.at wird nicht eingesetzt.

**Entgeltgrundlage:** Deine Angabe „übliche Facharbeiter-Gruppe mit abgeschlossener Lehre“ ist als Lohngruppe 3 umgesetzt: KV-Mindestgrundlohn 2.948,85 € brutto monatlich bei Vollzeit, Stand 2026. Dein höheres Gehaltsband ist in jeder Fassung ausdrücklich genannt. Quelle und Einstufungsgrundlage stehen im Kampagnen-Setup.

## Entscheidung

Bitte freigeben: **die genannten Texte und Formulare, den beschriebenen Motivvorschlag, die Kanäle und Einstellungen sowie den Gesamtrahmen von 569 €.**

Kurze Antwort genügt: „Version 1 samt Motiv und 569 € freigegeben“ – oder die gewünschten Änderungen nennen.

Antwort von Gerhard: **noch offen**.

Erst nach deiner Antwort werden die Anzeigen und die Kampagne veröffentlicht. Startdatum und Status werden anschließend in `systeme/kampagne/status.md` eingetragen.
