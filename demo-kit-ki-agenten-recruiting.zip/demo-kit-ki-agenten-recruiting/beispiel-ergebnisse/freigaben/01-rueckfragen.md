# Drei Rückfragen an Gerhard Wimmer

Status: beantwortet durch Gerhard Wimmer am 15. September 2026

Gerhard, der regionale Markt ist geprüft und das Stellenprofil vorbereitet. Für die Anzeige brauche ich diese Angaben:

1. **Gehalt:** Welches Band darf ich nennen – von welchem bis zu welchem monatlichen Bruttogrundlohn bei 38,5 Stunden, zuzüglich welcher Schichtzulagen? Bitte auch die für diese Tätigkeit bestätigte KV-Lohngruppe angeben. Zur Orientierung: Trenkwalder wirbt in Ternitz ab 3.478,51 € brutto monatlich; unser eigener Betrag kommt von dir. [Quelle](https://at.trenkwalder.com/en-AT/jobs/a0tbI00000WDl6lQAD)
2. **Arbeitszeit:** Wie lauten Früh- und Spätschicht von Montag bis Freitag genau? Gilt Freitag 12:00 Uhr auch in der Spätschichtwoche, und ist die getestete 4-Tage-Woche für diese Stelle möglich?
3. **Besetzungsbedarf:** Ist Kerns Nachfolge dieselbe CNC-Frässtelle, die laut Firmenprofil bereits seit vier Monaten offen ist, oder suchen wir insgesamt zwei Personen?

Kurze Antwort genügt:

- Gehaltsband / Zulagen / KV-Lohngruppe: …
- Schichtzeiten / Freitag / 4-Tage-Woche: …
- Insgesamt zu besetzende Stellen: …

Nach deiner Antwort erstelle ich Anzeige, Kanalvorschlag und Kampagne mit Kosten zur Veröffentlichungsfreigabe. Diese Rückfragen sind noch keine Freigabe für eine Veröffentlichung.

---

## Antworten von Gerhard Wimmer, 15.09.2026

Kurz, hab wenig Zeit:

- **Gehaltsband / Zulagen / KV-Lohngruppe:** 3.500 bis 4.100 € brutto pro Monat bei 38,5 Stunden, je nach Erfahrung. Schichtzulage kommt laut KV extra dazu. Lohngruppe ist die für Facharbeiter mit abgeschlossener Lehre im Metallgewerbe, den genauen Buchstaben schau ich nicht nach, nimm die übliche Facharbeiter-Gruppe. Das Band darf so in die Anzeige.
- **Schichtzeiten / Freitag / 4-Tage-Woche:** Früh 06:00 bis 14:30, Spät 14:00 bis 22:30, Montag bis Donnerstag. Freitag nur Frühschicht bis 12:00, gilt in beiden Wochen. Die 4-Tage-Woche bitte noch nicht nennen, die testen wir in der Montage, in der Zerspanung geht das im Zweischichtbetrieb derzeit nicht. Den Freitag ab 12:00 dafür hervorheben, das ist bei uns fix.
- **Insgesamt zu besetzende Stellen:** Eine Stelle. Das ist dieselbe, die seit vier Monaten offen ist. Der Kern war der, der sie bis jetzt mit abgedeckt hat. Sofort wäre schön, aber ich nehme auch jemanden mit drei Monaten Kündigungsfrist, wenn er passt. Leihpersonal will ich nicht.
