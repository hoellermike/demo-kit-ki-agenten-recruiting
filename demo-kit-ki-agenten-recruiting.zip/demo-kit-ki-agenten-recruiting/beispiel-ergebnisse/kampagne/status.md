# Veröffentlichungs- und Kampagnenstatus

Stand: 15. September 2026

Rückfragen beantwortet. Phase 2 vorbereitet. **Veröffentlichungs- und Budgetfreigabe ausständig.**

| Bestandteil | Status | Veröffentlichungsdatum | Geplanter Kostenrahmen | Veranlasste Ausgaben |
|---|---|---|---:|---:|
| Karriereseite samt Formular | Vorbereitet, nicht veröffentlicht | – | 0 € | 0 € |
| AMS | Vorbereitet, nicht veröffentlicht | – | 0 € | 0 € |
| willhaben | Vorbereitet, nicht veröffentlicht | – | 149 € | 0 € |
| Meta: drei Anzeigen, Formular und Motivvorschlag | Vorbereitet, nicht veröffentlicht | – | 420 € | 0 € |
| **Gesamt** | **Wartet auf Gerhard** | **–** | **569 €** | **0 €** |

Freigabeunterlage: `freigaben/02-veroeffentlichung.md`, Version 1. Eine Veröffentlichung ist bisher für keinen Kanal freigegeben. Die Dateien in `systeme/kanaele/` bilden das vorbereitete Paket; es gibt keinen Veröffentlichungseintrag.

Meta-Laufzeit: 21 Tage ab tatsächlichem Start nach Freigabe und Prüfung. willhaben: 30 Tage ab Veröffentlichung. Start und Ende werden erst beim jeweiligen Start datiert. Keine automatische Verlängerung.
