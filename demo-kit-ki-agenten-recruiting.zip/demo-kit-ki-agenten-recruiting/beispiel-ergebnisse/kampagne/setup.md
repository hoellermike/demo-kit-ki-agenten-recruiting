# Kampagnen-Setup – CNC-Fräsen in Ternitz

Version 1 · 15. September 2026 · vorbereitet, Freigabe ausständig

## Ziel und Angebot

Eine Stelle direkt bei Wimmer Metalltechnik besetzen. 3.500–4.100 € brutto monatlich bei 38,5 Stunden nach Erfahrung, zuzüglich KV-Schichtzulagen. Freitag ab 12:00 Uhr frei in beiden Schichtwochen. Start auch mit drei Monaten Kündigungsfrist möglich. Keine 4-Tage-Woche in dieser Stelle.

## Kanalauswahl

Die Kosten und Kanalerfahrungen stammen aus `systeme/plattformen.md`, der Richtwert aus `systeme/budget.md`.

| Kanal | Entscheidung und Begründung | Kosten | Laufzeit ab Veröffentlichung |
|---|---|---:|---|
| Meta: Facebook und Instagram | Hauptkanal für regional erreichbare Fachkräfte, die auch während einer Beschäftigung einen Wechsel erwägen. Die interne Erfahrung spricht hier stärker für Meta als für klassische Jobbörsen. | 420 € | 21 Tage |
| willhaben Jobs | Ergänzung für aktiv Suchende; laut Plattformübersicht regional stark bei gewerblichen Berufen. | 149 € | 30 Tage, keine automatische Verlängerung |
| AMS | Kostenloser Zugang zu aktiv Arbeitssuchenden. | 0 € | Bis Besetzung oder Rücknahme |
| Eigene Karriereseite | Vollständige Stelleninformation und direkte Bewerbung. | 0 € | Bis Besetzung oder Rücknahme |
| karriere.at | Vorerst nicht einsetzen: laut interner Übersicht für diese Rolle schwächer; das Kontingent bleibt verfügbar. | 0 € | Kein Start |

**Beantragter Gesamtrahmen: 569 €.** Kein Kanal wird vor der Veröffentlichungsfreigabe gestartet. Der Gesamtbetrag liegt über der Freigabegrenze von 300 €; er wird als ein Auftrag vorgelegt, nicht in Einzelbeträge aufgeteilt.

## Meta-Einstellungen

- Ziel: eingegangene Bewerbungen über das Bewerbungsformular, nicht bloße Klicks.
- Besondere Anzeigenkategorie: Beschäftigung / Employment.
- Gebiet: Ternitz mit 30 km Radius; keine Ortsausschlüsse oder Auswahl einzelner Postleitzahlen.
- Altersauswahl: vollständiger für Beschäftigungsanzeigen vorgegebener Bereich, keine eigene Altersgrenze und keine Altersansprache im Text.
- Geschlecht: alle. Keine Filter nach Herkunft, Familienstand oder anderen persönlichen Merkmalen.
- Keine Einschränkung nach Sprache der Benutzeroberfläche; die Anzeige ist auf Deutsch.
- Keine verpflichtenden Interessenfilter, keine hochgeladenen Bewerberlisten und keine ähnlichen Zielgruppen aus Bewerberdaten. Die fachliche Ansprache erfolgt durch Rolle und Inhalte.
- Eine Anzeigengruppe, damit das regionale Budget nicht auf mehrere Gruppen verteilt wird.
- Facebook-/Instagram-Feed sowie Stories; dieselbe Botschaft in passender Gestaltung.
- Drei Anzeigenvarianten im gemeinsamen Budget. Keine zusätzlichen 420 € je Variante.
- Gesamtbudget 420 € für 21 Tage, rechnerisch 20 € pro Tag. Das Gesamtlimit gilt verbindlich; der Tageswert ist der Durchschnitt.
- Start nach Freigabe und Plattformprüfung. Laut interner Übersicht ist dafür ein Vorlauf von 24 Stunden vorgesehen. Das tatsächliche Startdatum wird im Status eingetragen; bis dahin kein angenommenes Lieferdatum.
- Ende nach 21 Tagen tatsächlicher Schaltung. Keine automatische Verlängerung oder Budgeterhöhung.

Die breite Zielgruppe folgt dem Verzicht auf diskriminierende Auswahlmerkmale; Meta beschreibt entsprechende Einschränkungen für Beschäftigungswerbung. [Meta: Ads Fairness](https://about.fb.com/news/2023/01/an-update-on-our-ads-fairness-efforts/). Der Radius und die Laufzeit sind unsere Planung, keine behaupteten gesetzlichen Vorgaben.

## Drei Anzeigentexte

Die vollständigen, zur Freigabe vorgelegten Texte einschließlich Entgelt, Formular und Schaltflächen stehen in `systeme/kanaele/meta.md`:

1. **Freitag ab 12:00 frei:** planbares Wochenende als Einstieg.
2. **3.500–4.100 € plus KV-Zulagen:** Gehalt und direkte Anstellung als Einstieg.
3. **Heidenhain oder Siemens?:** konkrete Fertigungsarbeit und Weiterbildung als Einstieg.

## Motivvorschlag zur Freigabe

Ein ruhiges Schriftmotiv auf dunkelblauem Hintergrund, weiße Schrift, orangefarbener Akzent beim Freitag. Keine Personen oder fremden Betriebsfotos. Oben der ausgeschriebene Firmenname, darunter die Rolle, dann Gehalt und Freitag. Keine erfundenen Logos, Auszeichnungen oder Maschinenbilder.

**Exakter sichtbarer Text:**

> Wimmer Metalltechnik GmbH
>
> CNC-Fräsen in Ternitz (m/w/d)
>
> Freitag ab 12:00 frei
>
> 3.500–4.100 € brutto/Monat
>
> 38,5 Stunden · je nach Erfahrung
>
> plus KV-Schichtzulagen · Direktanstellung
>
> KV Metallgewerbe, LG 3: 2.948,85 € brutto/Monat bei Vollzeit, Stand 2026. Überzahlung im genannten Band.
>
> Jetzt bewerben

Formatvorschlag: Feed 1080 × 1350, Story 1080 × 1920. Alle Texte bleiben lesbar innerhalb der freien Fläche zwischen den Bedienelementen. Der Mindestlohn darf nicht unlesbar verkleinert werden. Die drei Texte verwenden dasselbe Motiv; die Wirkung der Einstiege lässt sich dadurch besser vergleichen.

Freigegeben werden sollen Motivtext und Gestaltungsvorschlag. Ein abweichendes Motiv oder andere öffentliche Aussagen brauchen eine neue Freigabe.

## Bewerbungsweg

Meta nutzt das Formular aus `systeme/kanaele/meta.md`; die Karriereseite enthält ihr Formular in der Vollfassung. AMS und willhaben nutzen die jeweilige Bewerbungsfunktion. Ein Kontakt ist mit Name und mindestens einer Kontaktmöglichkeit möglich; ein Lebenslauf ist für den Erstkontakt nicht erforderlich.

Eingänge werden in `systeme/eingang/` abgelegt. Name, Kanal, Eingangsdatum und Kontakt werden unverändert in `systeme/berichte/bewerbereingang.md` übernommen. Für jede neue Bewerbung wird ein freundlicher Bestätigungsentwurf angelegt und der Eingang im Tagesbericht an Gerhard gemeldet. Keine automatische Vorauswahl, kein Punktesystem und keine Zusage oder Absage. Die Entscheidung trifft Gerhard.

## Beobachtung und Änderungsregeln

Bei jeder Tagesrunde: Eingänge je Kanal, Ausgaben und Kosten je Bewerbung erfassen. Kosten je Bewerbung = bisherige Kanalkosten geteilt durch zugeordnete Bewerbungen. Bei null Bewerbungen wird kein künstlicher Kostenwert berechnet. Fehlende Zahlen werden als offen geführt.

- Richtwert: 25–40 € je Bewerbung laut `systeme/budget.md`; keine Aussage über die Eignung von Menschen.
- Nach drei Tagen ohne Bewerbung je Kanal: Ausspielung und Bewerbungsweg prüfen; konkrete Änderung vorschlagen.
- Sobald Kosten je Bewerbung über 40 € liegen: Abweichung samt Ausgaben und Eingängen melden und Änderung vorschlagen. Kleine Fallzahlen ausdrücklich nennen.
- Bei willhaben die einmaligen 149 € separat ausweisen; der Vergleich zu laufenden Meta-Kosten ist nur eingeschränkt aussagekräftig.
- Änderungen an Budget oder dessen Verteilung brauchen eine Freigabe, auch wenn die Gesamtsumme gleich bliebe. Neue Texte und Motive ebenfalls vorlegen.
- Bereits freigegebene Meta-Varianten dürfen innerhalb derselben Anzeigengruppe mit unterschiedlicher Ausspielung laufen; der gemeinsame Rahmen bleibt gleich.
- Tagesbericht maximal zehn Zeilen. Nach Laufzeitende Ergebnisse vorlegen; Fortsetzung nur nach neuer Freigabe.

## Grundlage der Entgeltangaben

Die vom Chef genannte übliche Facharbeiter-Gruppe mit Lehrabschluss entspricht der **Lohngruppe 3**, Mindestgrundlohn **2.948,85 €** monatlich ab 1. Jänner 2026. Die Anzeige verwendet diese Zuordnung auf Grundlage seiner Tätigkeits-/Gruppenangabe. Das angebotene Band stammt ausschließlich von Gerhard. [WKO-Lohnordnung](https://www.wko.at/kollektivvertrag/lohnordnung-metallgewerbe-arbeiter-2026)

Eine Einstufung in eine höhere Gruppe richtet sich nach den tatsächlichen Aufgaben und der Verantwortung. Die Anforderungen einer höheren Gruppe dürfen nicht durch die Bezeichnung „übliche Facharbeiter-Gruppe“ ersetzt werden. Die Stellenbeschreibung enthält keine Personalführung oder Kundenberatung. [WKO-KV, Abschnitt IX](https://www.wko.at/kollektivvertrag/kollektivvertrag-eisen-metallverarbeitenden-gewerbe-2026)

Jede Anzeigenfassung enthält das monatliche KV-Mindestentgelt und die Überzahlung. Variable Schichtzulagen werden zusätzlich genannt, ohne einen nicht belegten Monatsbetrag zu erfinden. [WKO: Mindestentgelt im Stelleninserat](https://www.wko.at/einstellen/angabe-mindestentgelts-stelleninserat)

Die Schichtzeiten werden genau nach Gerhards Antwort übernommen. Daraus werden keine bezahlten Stunden oder Pausen errechnet; ein Pausenplan war nicht Teil seiner Angaben.
