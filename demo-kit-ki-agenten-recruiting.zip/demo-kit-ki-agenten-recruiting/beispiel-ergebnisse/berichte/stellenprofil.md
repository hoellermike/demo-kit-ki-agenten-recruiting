# Stellenprofil – nach Antworten des Chefs

Stand: 15. September 2026. Grundlagen: `firma/firmenprofil.md`, `auftrag.md` und Gerhards Antworten in `freigaben/01-rueckfragen.md`.

## Bedarf und Konditionen

Eine Zerspanungstechniker:in CNC-Fräsen (m/w/d) für Wimmer Metalltechnik GmbH, Ternitz. Es ist die bereits offene Stelle, die Kern mit abgedeckt hat. Direktanstellung, keine Arbeitskräfteüberlassung. Start ab sofort oder nach Vereinbarung, auch mit drei Monaten Kündigungsfrist.

38,5 Wochenstunden; Montag bis Donnerstag Frühschicht 06:00–14:30 Uhr oder Spätschicht 14:00–22:30 Uhr. Freitag nur Frühschicht bis 12:00 Uhr in beiden Schichtwochen. Keine 4-Tage-Woche für die Zerspanung.

3.500–4.100 € brutto monatlich nach Erfahrung, Schichtzulagen laut KV zusätzlich. Die vom Chef genannte Facharbeiter-Gruppe mit Lehre wird als LG 3 zugeordnet, 2.948,85 € monatlicher KV-Mindestgrundlohn 2026. Einstufungsgrundlage und Quellen: `systeme/kampagne/setup.md`.

## Tätigkeit

CNC-Fräsmaschinen einrichten, mit Heidenhain oder Siemens programmieren, Einzelteile und Kleinserien nach Zeichnung fertigen und Werkstücke prüfen. Maschinenpark laut Firmenprofil unter anderem DMG MORI, Hermle und Mazak; 3- und 5-Achs-Bearbeitung. Keine bestimmte Maschine exklusiv zugesagt.

## Muss-Kriterien

- Abgeschlossene Ausbildung in Zerspanungstechnik, Maschinenbautechnik oder vergleichbar.
- Mindestens zwei Jahre CNC-Fräserfahrung.
- Programmierkenntnisse Heidenhain oder Siemens; Heidenhain bevorzugt, Siemens ausreichend.
- Bereitschaft zur Zweischicht.
- Deutsch für Arbeitsanweisungen und Zeichnungen, mindestens B1.

## Kann-Kriterien

- 5-Achs-Erfahrung, CAM-Kenntnisse, vertiefte Messtechnik und Qualitätsprüfung, Staplerschein.
- Ein kurzer Arbeitsweg ist ein Wunsch, kein Ausschlusskriterium.

## Weitere Bedingungen

Steuerungs-/CAM-Weiterbildung, Firmenparkplatz und Mittagessen-Zuschuss laut Firmenprofil. Die Auswahl von Bewerber:innen trifft ausschließlich Gerhard. Die veröffentlichten Stellenangaben und das Budget warten noch auf Freigabe.
