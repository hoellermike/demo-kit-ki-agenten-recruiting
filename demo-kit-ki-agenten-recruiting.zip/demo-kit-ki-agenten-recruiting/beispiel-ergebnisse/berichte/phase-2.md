# Phase 2 – Anzeigen und Kampagne bereit zur Freigabe

15. September 2026

Gerhard, die Vollfassung, AMS- und willhaben-Anzeigen sowie drei Facebook-/Instagram-Texte sind fertig. Im Vordergrund stehen dein Gehaltsband und Freitag ab 12:00 Uhr frei. Direktanstellung und ein späterer Einstieg sind berücksichtigt.

Ich empfehle **Meta für 420 € über 21 Tage**, **willhaben für 149 € über 30 Tage** sowie kostenlos AMS und die Karriereseite. **Gesamt: 569 €.** Grundlage sind unsere Kanalpreise und Erfahrungen in `systeme/plattformen.md`. Das karriere.at-Kontingent bleibt verfügbar.

Das Schriftmotiv und die Bewerbungsformulare sind im Paket beschrieben. Die übliche Facharbeiter-Gruppe ist nach deiner Angabe als LG 3 mit 2.948,85 € KV-Mindestgrundlohn umgesetzt; dein Angebot liegt darüber. [WKO-Lohnordnung](https://www.wko.at/kollektivvertrag/lohnordnung-metallgewerbe-arbeiter-2026)

**Jetzt brauche ich deine Freigabe für das Paket und 569 €:** `freigaben/02-veroeffentlichung.md`. Danach starte ich die Kanäle und führe die Tagesrunden bei den nächsten Aufrufen durch.

Stand: vorbereitet, nichts veröffentlicht, 0 € Ausgaben. Öffentliche Inhalte brauchen laut `systeme/budget.md` immer deine Freigabe; auch der Gesamtrahmen liegt über 300 €.
