# Phase 1 – Auftrag und Markt geprüft

15. September 2026 · Rückfragen an Gerhard offen

Gerhard, das Stellenprofil für CNC-Fräsen ist vorbereitet. Heidenhain bleibt bevorzugt, Siemens reicht ebenfalls.

**Der wichtigste Punkt ist das Gehalt:** Trenkwalder sucht in Ternitz ab **3.478,51 € brutto/Monat** mit Überzahlung. Wimmers Band fehlt noch; einen Lohnnachteil kann ich deshalb nicht beziffern. [Konkurrenzangebot](https://at.trenkwalder.com/en-AT/jobs/a0tbI00000WDl6lQAD)

Bei den Arbeitszeiten bietet Kernbeis in Wöllersdorf auch Teilzeit. Unser Vollzeit-Zweischichtmodell spricht dadurch einen engeren Kreis an. Der frühe Freitag könnte helfen, sobald seine Geltung für beide Schichten klar ist. [Kernbeis](https://www.kernbeis.com/karriere-cnc/)

**Ich brauche deine Antwort zu Gehalt, Schichtzeiten und der Zahl der zu besetzenden Stellen.** Die Fragen stehen in `freigaben/01-rueckfragen.md`. Danach bereite ich Anzeige und Kampagne mit Kosten zur Freigabe vor.

Marktvergleich mit Quellen: `systeme/berichte/marktcheck.md`. Muss- und Kann-Kriterien: `systeme/berichte/stellenprofil.md`.

Stand: nichts veröffentlicht, keine Ausgaben veranlasst. Phase 2 wartet gemäß Arbeitsauftrag auf die Antworten.
