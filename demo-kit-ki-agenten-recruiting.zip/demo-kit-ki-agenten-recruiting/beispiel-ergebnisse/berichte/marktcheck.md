# Regionaler Marktcheck – CNC-Fräsen

Stand: 15. September 2026. Suchgebiet: Ternitz, Neunkirchen und der Raum Wiener Neustadt einschließlich Wöllersdorf. Die genannten Orte sind durch die Inserate belegt; individuelle Pendelzeiten wurden nicht ermittelt.

## Wer sucht und was angeboten wird

| Anbieter / Arbeitsort | Gesuchte Arbeit | Veröffentlichte Entlohnung | Konditionen |
|---|---|---|---|
| Trenkwalder / Ternitz, nicht genannter Industriekunde | Zerspanung, CNC-Drehen und/oder Fräsen | Ab **3.478,51 € brutto/Monat**, Überzahlung möglich; **38,5 Stunden/Woche** | Schichtbetrieb, Weiterbildung, Kantine, Fitnessbereich, Parkplatz; Arbeitnehmerüberlassung. [Inserat vom 7. September 2026](https://at.trenkwalder.com/en-AT/jobs/a0tbI00000WDl6lQAD) |
| staff24 / Wiener Neustadt-Land, nicht genannter Kunde | CNC-Fräsen, Heidenhain, Einzelteile und Kleinserien | Ab **3.000 € brutto/Monat**, Überzahlung möglich | Vollzeit, selbstständige Fertigung und Qualitätskontrolle; konkrete Schichtzeiten nicht genannt. [Originalinserat](https://www.staff24.com/jobs/cnc-fraeser-m-w-d-1996/) |
| CNC Frästechnik Kernbeis / Wöllersdorf | CNC-Fräsen, Programmierung, bevorzugt Heidenhain | **40.000–55.000 € brutto/Jahr** auf Vollzeitbasis, nach Ausbildung und Erfahrung | Voll- oder Teilzeit, individuelle Einarbeitung, familiäres Umfeld, Einzelteile und Kleinserien; konkrete Schichtzeiten nicht genannt. [Arbeitgeberseite](https://www.kernbeis.com/karriere-cnc/) |

Das sind öffentlich auffindbare Angebote, keine bestätigten Vertragslöhne und kein repräsentativer Gehaltsdurchschnitt. Mindestbeträge, Jahresband und unterschiedliche Kollektivverträge sind nicht unmittelbar gleichzusetzen. Bei staff24 und Kernbeis fehlt ein Veröffentlichungsdatum. Die Kundennamen der Personaldienstleister bleiben offen; daraus lassen sich keine zusätzlichen, eindeutig verschiedenen Arbeitgeber ableiten.

Ein gefundenes willhaben-Inserat für CNC-Drehen und Fräsen in Neunkirchen leitet auf eine Seite mit Ablaufhinweis weiter und zählt deshalb nicht als aktuelles Angebot. [Fundstelle](https://www.willhaben.at/jobs/job/cnc-dreher-u-fraeser-m-w-d/12555445)

## Wo Wimmer im Vergleich steht

- **Entlohnung: noch nicht beurteilbar.** Im Firmenprofil steht nur Überzahlung nach Erfahrung. Die Konkurrenz nennt konkrete Beträge. Hier fehlt Wimmer bereits bei der Klarheit des Angebots ein entscheidender Punkt. Ob Wimmer tatsächlich weniger zahlt, lässt sich erst mit dem Gehaltsband sagen.
- **Arbeitszeit: weniger Auswahl als bei Kernbeis.** Wimmer sucht ausschließlich Vollzeit im Zweischichtbetrieb; Kernbeis bietet auch Teilzeit. Wie attraktiv Wimmers Freitag ist, hängt davon ab, ob das Ende um **12:00 Uhr** für beide Schichten gilt. Quelle für Wimmers Angaben: `firma/firmenprofil.md`.
- **Gute fachliche Ausgangslage:** Heidenhain oder Siemens, moderne Maschinen, Einzelteile und Kleinserien sowie Steuerungs- und CAM-Kurse liefern konkrete Inhalte. Weiterbildung und Parkplatz bietet aber auch Trenkwalder; diese Vorteile allein heben Wimmer nicht ab. Quellen: Firmenprofil und obige Inserate.
- Die **4-Tage-Woche** ist laut Firmenprofil nur ein Versuch in einer Abteilung. Sie ist für diese Stelle nicht zugesichert und wird daher nicht als Stellenangebot verwendet.

## Kollektivvertrag als Untergrenze

Für Arbeiter:innen im Metallgewerbe gelten ab **1. Jänner 2026** folgende monatliche Mindestgrundlöhne: **2.948,85 €** in Lohngruppe 3 (Facharbeiter:in), **3.397,52 €** in Lohngruppe 2 (qualifizierte Facharbeiter:in) und **3.808,83 €** in Lohngruppe 1 (Spitzenfacharbeiter:in). [WKO-Lohnordnung](https://www.wko.at/kollektivvertrag/lohnordnung-metallgewerbe-arbeiter-2026)

Die passende Einstufung hängt von der tatsächlich ausgeübten Tätigkeit ab. Sie wird nicht allein aus dem Stellentitel oder den Erfahrungsjahren abgeleitet. Vor der Anzeige sind Lohngruppe, Grundlohn und Zulagen zu klären; die Tabellenwerte sind kein festgelegtes Gehaltsangebot von Wimmer. [WKO-Kollektivvertrag, Abschnitt IX](https://www.wko.at/kollektivvertrag/kollektivvertrag-eisen-metallverarbeitenden-gewerbe-2026)

## Wo die Fachkräfte zu erreichen sind

Das AMS zählt für Zerspanungstechnik in Niederösterreich **1.079 Onlineinserate im Jahr 2025**. Das beschreibt die Nachfrage nach dem Beruf, nicht die Zahl verfügbarer Bewerber:innen. Als Beschäftigungsfelder nennt das AMS unter anderem Maschinen- und Anlagenbau, Fahrzeugbau und Metallindustrie. [AMS JobBarometer](https://jobbarometer.ams.at/berufe/367/86)

Daraus leite ich als Suchansatz Fachkräfte aus der regionalen Metallfertigung ab, die bereits beschäftigt sind und einen Wechsel erwägen, ergänzt um aktiv Arbeitssuchende. Die örtlichen Inserate belegen Konkurrenz im selben Berufsfeld; sie belegen nicht, wo einzelne Kandidat:innen wohnen oder dass diese wechseln möchten.

Für die spätere Kanalplanung sind Meta für Wechselinteressierte sowie AMS und willhaben für aktiv Suchende zu prüfen. Die interne Erfahrung mit Meta und willhaben steht in `systeme/plattformen.md`; sie ist keine unabhängig bestätigte Marktstatistik. Ein zusätzlicher Einsatz des karriere.at-Kontingents ist daraus derzeit nicht begründet. Die endgültige Kanal- und Budgetentscheidung folgt nach Klärung des Auftrags.
