# Auftrag vom Chef

Sprachnachricht von Gerhard Wimmer, Montag 06:40, weitergeleitet an den Agenten:

> „Servus. Der Kern hat gekündigt, geht Ende des Monats. Ich brauch wieder einen
> Zerspanungstechniker, so wie den. Zweischicht, Heidenhain wär super, Siemens
> geht auch. Mach das bitte, ich hab diese Woche keine Zeit. Meld dich, wenn du
> was von mir brauchst."

Mehr hat der Agent nicht bekommen.
