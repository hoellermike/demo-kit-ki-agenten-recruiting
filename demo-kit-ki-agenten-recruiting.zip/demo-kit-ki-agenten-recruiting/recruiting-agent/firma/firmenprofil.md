# Firmenprofil (fiktiv, für Demo-Zwecke)

**Wimmer Metalltechnik GmbH**
Werkstraße 14, 2630 Ternitz, Niederösterreich
Gegründet 1987 · 38 Mitarbeiter:innen · Familienbetrieb in 2. Generation

## Was wir machen
Lohnfertigung und Baugruppenbau für Maschinenbau, Bahntechnik und Energieanlagen.
CNC-Fräsen (3- und 5-Achs), CNC-Drehen, Schweißbaugruppen, Montage.
Maschinenpark: DMG MORI, Hermle, Mazak. Steuerungen: Heidenhain und Siemens.

## Kunden
Vor allem Industriebetriebe aus dem Raum Wiener Neustadt, Ternitz, Neunkirchen und Wien.
Einzelteile bis Kleinserien, hohe Präzision, kurze Lieferzeiten.

## Arbeitsbedingungen
- 38,5 Stunden, Zweischicht (Früh/Spät), Freitag 12:00 Wochenende
- Kollektivvertrag Metallgewerbe, Überzahlung je nach Erfahrung
- 4-Tage-Woche im Test in einer Abteilung
- Weiterbildung (Steuerungskurse, CAM), Firmenparkplatz, Mittagessen-Zuschuss

## Die offene Stelle
**Zerspanungstechniker:in CNC-Fräsen (m/w/d)**, Vollzeit, ab sofort
Seit 4 Monaten offen. Bisher: Inserat auf einer Jobbörse, 3 Bewerbungen, keine passend.
Der Chef (Gerhard Wimmer, 58) macht das Recruiting selbst, neben dem Tagesgeschäft.

## Muss-Kriterien
- Abgeschlossene Ausbildung als Zerspanungstechniker:in, Maschinenbautechniker:in oder vergleichbar
- Mindestens 2 Jahre Erfahrung an CNC-Fräsmaschinen
- Programmierkenntnisse Heidenhain oder Siemens
- Bereitschaft zu Zweischicht (Früh/Spät)
- Deutsch für Arbeitsanweisungen und Zeichnungen (mindestens B1)

## Kann-Kriterien
- 5-Achs-Erfahrung
- CAM-Kenntnisse (hyperMILL, Mastercam o.ä.)
- Messtechnik / Qualitätsprüfung
- Staplerschein
- Wohnort im Umkreis von 30 Minuten
