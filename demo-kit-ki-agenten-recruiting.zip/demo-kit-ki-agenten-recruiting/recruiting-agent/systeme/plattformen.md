# Verfügbare Kanäle (Stand 2026)

| Kanal | Zugang | Kosten | Reichweite regional | Vorlauf |
|---|---|---|---|---|
| AMS eJob-Room | Betriebskonto vorhanden | kostenlos | hoch, alle Arbeitsuchenden | sofort |
| karriere.at | Kontingent: 2 Anzeigen frei | im Kontingent | mittel, aktiv Suchende | sofort |
| willhaben Jobs | Konto vorhanden | 149 € / 30 Tage | mittel, regional stark | sofort |
| Eigene Karriereseite | direkter Zugriff | kostenlos | niedrig ohne Werbung | sofort |
| Meta Ads (Facebook/Instagram) | Werbekonto vorhanden | frei wählbar | sehr hoch, auch passiv Suchende | 24 h Prüfung |

## Hinweise aus der Erfahrung
- Bei Facharbeitern in der Industrie kommen 70 bis 80 Prozent der Bewerbungen
  über Meta, nicht über die Jobbörsen. Die Jobbörsen erreichen nur, wer gerade
  aktiv sucht. Das sind bei Zerspanungstechnikern sehr wenige.
- willhaben lohnt bei gewerblichen Berufen im ländlichen Raum.
- karriere.at-Kontingent nicht verschwenden, das kostet sonst 890 € pro Anzeige.
