# Budget- und Freigaberahmen

Vom Chef einmalig festgelegt, gilt für alle Stellen:

- **Bis 300 €** darf der Agent ohne Rückfrage ausgeben.
- **Über 300 €** braucht eine Freigabe. Der Agent legt sie in `freigaben/` ab
  und wartet. Er gibt nichts aus, solange keine Antwort da ist.
- **Alles, was öffentlich sichtbar wird**, braucht eine Freigabe, unabhängig
  vom Betrag. Also jede Anzeige und jedes Werbemotiv, bevor es online geht.
- **Gehaltsangaben** in Anzeigen legt immer der Chef fest, nie der Agent.

Richtwert aus vergangenen Kampagnen: 25 bis 40 € pro Bewerbung bei
gewerblichen Fachkräften im Umkreis von 30 km.
