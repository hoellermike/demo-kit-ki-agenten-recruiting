# Die drei Prompts

Ein Agent, drei Phasen. Sie tippen jeweils einen Satz, der Agent macht den Rest.
Vorher: Den Ordner `recruiting-agent` in Ihrem KI-Werkzeug öffnen (siehe README im Hauptordner).

## Phase 1: Auftrag verstehen und Markt prüfen

```
Der Chef hat mir eine Sprachnachricht geschickt, die liegt in auftrag.md. Übernimm das bitte.
```

Was passieren soll: Der Agent liest Auftrag und Firmenprofil, recherchiert im Web, wer im Umkreis dieselbe Rolle sucht und was gezahlt wird, schreibt ein Stellenprofil und stellt Ihnen genau drei Rückfragen in `freigaben/01-rueckfragen.md`. Dann stoppt er.

Ihr Schritt: Die drei Fragen unten in dieser Datei beantworten, so wie ein Chef es per Nachricht tun würde. Ein Beispiel finden Sie in `beispiel-ergebnisse/freigaben/01-rueckfragen.md`.

## Phase 2: Anzeige, Kanäle, Kampagne

```
Ich habe deine Rückfragen beantwortet, schau in freigaben/01-rueckfragen.md. Mach weiter.
```

Was passieren soll: Der Agent schreibt die Anzeige in mehreren Fassungen, entscheidet selbst, welche Kanäle sich lohnen, setzt die Social-Media-Kampagne auf und legt alles mit Kosten in `freigaben/02-veroeffentlichung.md` zur Freigabe vor. Er veröffentlicht nichts.

Ihr Schritt: Unten in dieser Datei die Freigabe eintragen, zum Beispiel: „Version 1 samt Motiv und 569 € freigegeben. Gerhard Wimmer, 15.09.2026“.

## Phase 3: Betrieb

```
Die Freigabe ist da, schau in freigaben/02-veroeffentlichung.md. Ab jetzt läufst du täglich. Fang an.
```

Während er arbeitet, legen Sie eine Bewerbung in den Eingang: eine Datei aus `beispiel-bewerbungen/` nach `recruiting-agent/systeme/eingang/` kopieren. Dann tippen:

```
Es ist gerade eine Bewerbung reingekommen.
```

Was passieren soll: Der Agent bestätigt den Eingang, legt die Bewerbung ab, trägt sie in die Übersicht ein und schreibt einen Tagesbericht. Er bewertet die Person nicht. Das ist Absicht, siehe README.

## Von vorne anfangen

Die Ordner `freigaben`, `protokoll`, `systeme/kanaele`, `systeme/kampagne`, `systeme/eingang` und `systeme/berichte` leeren. Alles andere bleibt.
