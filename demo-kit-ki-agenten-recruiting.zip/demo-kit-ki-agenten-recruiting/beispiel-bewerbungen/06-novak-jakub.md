# Bewerbung: Jakub Novák

Eingegangen über: Mitarbeiter-Empfehlung (WhatsApp-Weiterleitung, danach Lebenslauf per Mail)
Wohnort: 2620 Neunkirchen
Kontakt: 0664 000 11 06 (fiktiv) · jakub.novak@example.at

## Ausbildung
- Fachschule Maschinenbau (Stredná priemyselná škola strojnícka), Trnava, Abschluss 2015, in Österreich als Fachschule anerkannt (Bescheid liegt bei)
- ÖSD-Zertifikat Deutsch B2, 2024

## Berufserfahrung
- 2015 bis 2019: CNC-Fräser, Automobilzulieferer Trnava (3-Achs, Fanuc)
- 2019 bis 2024: CNC-Fräser, Maschinenbau Bratislava (5-Achs Mazak Variaxis, Mazatrol und Siemens 840D)
- seit 2024: CNC-Fräser bei einem Zulieferbetrieb in Wiener Neustadt (5-Achs, Siemens 840D, zusätzlich Erstmusterprüfung auf Messmaschine)

## Kenntnisse
- Steuerungen: Siemens 840D (sehr gut), Fanuc (gut), Mazatrol (gut), Heidenhain (nein)
- CAM: keine, Programmierung an der Maschine
- Messtechnik: Messmaschine Mitutoyo, Erstmusterprüfung, Prüfprotokolle
- Staplerschein: ja (in Österreich gemacht, 2025)
- Schweißen: nein
- Englisch: gut (Arbeitssprache im Betrieb in Bratislava war teilweise Englisch)
- Führerschein B, eigenes Auto

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: ja
- Überstunden / gelegentlich Samstag: ja
- Verfügbarkeit: Kündigungsfrist 1 Monat
- Gehaltsvorstellung: 3.700 brutto
- Warum wechseln: Ich wohne seit 2 Jahren in Neunkirchen und fahre jeden Tag nach Wiener Neustadt. Ein Kollege von Ihnen hat mir die Stelle geschickt. Ternitz wäre 10 Minuten. Und ich möchte mehr Einzelteile machen, weniger Serie.

## Nachricht
Guten Tag Herr Wimmer, Ihr Mitarbeiter Herr Steiner hat mir die Stelle per WhatsApp geschickt. Ich arbeite seit 11 Jahren an CNC-Fräsmaschinen, davon 7 Jahre 5-Achs. Siemens kann ich sehr gut, Heidenhain würde ich lernen müssen. Ich schicke Ihnen meinen Lebenslauf und den Anerkennungsbescheid im Anhang. Freundliche Grüße, Jakub Novák
