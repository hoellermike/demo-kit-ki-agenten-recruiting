# Bewerbung: Peter Grabner

Eingegangen über: Jobbörse (Lebenslauf als PDF, Anschreiben)
Wohnort: 1100 Wien
Kontakt: 0664 000 11 05 (fiktiv) · peter.grabner@example.at

## Ausbildung
- Lehre Bürokaufmann, Lehrabschluss 2013
- Ausbildung zum Logistik-Disponenten (WIFI, 2017)

## Berufserfahrung
- 2013 bis 2017: Sachbearbeiter Einkauf, Handelsunternehmen Wien
- seit 2017: Disponent Logistik, Speditionsunternehmen Wien (Tourenplanung, Kundenkontakt, Lagerkoordination)

## Kenntnisse
- Steuerungen: keine
- CAM: keine, aber "sehr gute Computerkenntnisse (Excel, SAP)"
- Messtechnik: keine
- Staplerschein: ja (Lager)
- Schweißen: nein
- Englisch: gut (Kundenkontakt mit ausländischen Speditionen)
- Führerschein B und C, eigenes Auto
- Hobby: Modellbau, eigene kleine Hobby-Fräse (Proxxon) im Keller

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: ja
- Überstunden / gelegentlich Samstag: ja
- Verfügbarkeit: Kündigungsfrist 1 Monat
- Gehaltsvorstellung: 2.800 brutto, "auch weniger für den Einstieg"
- Warum wechseln: Ich sitze seit 13 Jahren im Büro und will endlich etwas mit den Händen machen. Fahrzeit nach Ternitz wären 50 Minuten, das wäre mir der Wechsel wert.

## Nachricht
Sehr geehrte Damen und Herren, ich bewerbe mich mit großem Interesse um die Stelle als Zerspanungstechniker. Auch wenn ich keine Ausbildung in diesem Bereich habe, bringe ich handwerkliches Geschick, hohe Lernbereitschaft und Zuverlässigkeit mit. Ich bin überzeugt, mich schnell einarbeiten zu können. Über eine Einladung zu einem Gespräch würde ich mich sehr freuen. Mit freundlichen Grüßen, Peter Grabner
