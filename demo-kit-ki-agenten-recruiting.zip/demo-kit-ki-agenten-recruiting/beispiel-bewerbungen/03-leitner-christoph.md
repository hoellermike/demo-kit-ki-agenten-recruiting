# Bewerbung: Christoph Leitner

Eingegangen über: Karriereseite (Lebenslauf als PDF, Anschreiben)
Wohnort: 2560 Berndorf
Kontakt: 0664 000 11 03 (fiktiv) · c.leitner@example.at

## Ausbildung
- Lehre Zerspanungstechnik, Lehrabschluss 2011 (Betrieb in Berndorf)
- Steuerungsschulung Heidenhain TNC 640 (Herstellerkurs 2018), 5-Achs-Programmierung (2020)

## Berufserfahrung
- 2011 bis 2017: CNC-Fräser, Werkzeugbau Berndorf (3-Achs, Heidenhain)
- seit 2017: Zerspanungstechniker und stellvertretender Schichtführer, Sondermaschinenbau in Baden (5-Achs DMG MORI DMU 50, Heidenhain TNC 640, hyperMILL, Erstmusterprüfung auf Messarm)

## Kenntnisse
- Steuerungen: Heidenhain TNC 640 (sehr gut), Siemens (Grundkenntnisse)
- CAM: hyperMILL (sehr gut, programmiere für 3 Maschinen)
- Messtechnik: Messarm, Erstmusterprüfung, Prüfpläne erstellen
- Staplerschein: ja
- Schweißen: WIG, gute Kenntnisse
- Englisch: gut
- Führerschein B, eigenes Auto

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: Derzeit nur Frühschicht möglich, weil ich die Kinderbetreuung am Nachmittag übernehme. Ab Herbst 2027 wäre Spätschicht wahrscheinlich wieder möglich.
- Überstunden / gelegentlich Samstag: Samstag ja, Überstunden unter der Woche nur bis 15:00
- Verfügbarkeit: Kündigungsfrist 3 Monate
- Gehaltsvorstellung: 4.300 brutto
- Warum wechseln: Mein aktueller Betrieb hat 45 Minuten Fahrzeit, Ternitz wäre 20. Und ich will wieder mehr an der Maschine stehen statt Schichtpläne schreiben.

## Nachricht
Sehr geehrter Herr Wimmer, ich bewerbe mich als Zerspanungstechniker. 15 Jahre Erfahrung, davon 9 auf 5-Achs mit Heidenhain und hyperMILL. Ich muss allerdings gleich ehrlich sagen: Spätschicht geht bei mir derzeit familiär nicht, nur Frühschicht. Falls das für Sie trotzdem interessant ist, freue ich mich über ein Gespräch. Mit freundlichen Grüßen, Christoph Leitner
