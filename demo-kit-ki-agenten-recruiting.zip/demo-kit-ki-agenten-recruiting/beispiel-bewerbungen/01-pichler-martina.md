# Bewerbung: Martina Pichler

Eingegangen über: Karriereseite (Kurzbewerbung + Lebenslauf)
Wohnort: 2620 Neunkirchen
Kontakt: 0664 000 11 01 (fiktiv) · m.pichler@example.at

## Ausbildung
- Lehre Zerspanungstechnik, Lehrabschluss 2014 (Betrieb in Wiener Neustadt)
- Werkmeisterschule Maschinenbau, Abschluss 2019, berufsbegleitend

## Berufserfahrung
- 2014 bis 2019: CNC-Fräserin, Lohnfertigung Wiener Neustadt (3-Achs, Heidenhain iTNC 530)
- seit 2019: Zerspanungstechnikerin, Werkzeugbau in Wiener Neustadt (5-Achs Hermle C 32, Heidenhain TNC 640, Programmierung an der Maschine und über hyperMILL)
- seit 2022 zusätzlich verantwortlich für Erstmusterprüfung auf Zeiss-Messmaschine

## Kenntnisse
- Steuerungen: Heidenhain TNC 640 und iTNC 530 (sehr gut), Siemens 840D (Grundkenntnisse)
- CAM: hyperMILL (gut)
- Messtechnik: Zeiss Calypso, Erstmusterprüfung, Messmittelverwaltung
- Staplerschein: ja (2016)
- Schweißen: nein
- Englisch: gut, Maschinendokumentation und Schulungen auf Englisch kein Problem
- Führerschein B, eigenes Auto

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: ja, mache ich aktuell auch
- Überstunden / gelegentlich Samstag: ja, nach Absprache
- Verfügbarkeit: Kündigungsfrist 6 Wochen zum Quartalsende, also frühestens 1. Jänner 2027
- Gehaltsvorstellung: rund 4.000 brutto pro Monat
- Warum wechseln: Aktueller Betrieb wird von einem Konzern übernommen, ich will lieber in einen Familienbetrieb, und Ternitz ist von Neunkirchen 10 Minuten.

## Nachricht
Guten Tag Herr Wimmer, ich habe Ihre Anzeige über eine Kollegin bekommen. Ich arbeite seit 10 Jahren an CNC-Fräsmaschinen, die letzten 5 Jahre auf 5-Achs Hermle mit Heidenhain. Die Hermle C 42 bei Ihnen würde mich sehr interessieren. Ich kann gerne nach der Arbeit auf einen Kaffee vorbeikommen. Mit freundlichen Grüßen, Martina Pichler
