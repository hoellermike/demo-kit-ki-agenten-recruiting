# Bewerbung: Daniela Hofer

Eingegangen über: Facebook-Anzeige (Kurzbewerbung per Formular)
Wohnort: 8680 Mürzzuschlag
Kontakt: 0664 000 11 04 (fiktiv) · daniela.hofer@example.at

## Ausbildung
- Lehre Metalltechnik, Schwerpunkt Stahlbautechnik, Lehrabschluss 2020 (Betrieb in Kapfenberg)
- WIFI-Kurs "CNC-Fräsen Grundlagen, Siemens ShopMill", 80 Stunden, abgeschlossen März 2025

## Berufserfahrung
- 2020 bis 2024: Stahlbauschlosserin, Stahlbau Kapfenberg (Zuschnitt, Schweißen, Montage)
- seit 2024: Metalltechnikerin in einem kleinen Betrieb in Mürzzuschlag; seit Sommer 2025 zusätzlich an einer konventionellen Fräse und fallweise an der CNC-Fräse (Siemens ShopMill, einfache Teile, Programme kommen vom Kollegen)

## Kenntnisse
- Steuerungen: Siemens ShopMill (Grundkenntnisse, Kurs plus ca. 1 Jahr fallweise Praxis)
- CAM: keine
- Messtechnik: Handmessmittel
- Staplerschein: ja
- Schweißen: MAG und WIG, sehr gut (Hauptaufgabe der letzten Jahre)
- Englisch: Grundkenntnisse
- Führerschein B, eigenes Auto

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: ja
- Überstunden / gelegentlich Samstag: ja
- Verfügbarkeit: sofort (Kündigungsfrist 2 Wochen)
- Gehaltsvorstellung: 3.000 brutto
- Warum wechseln: Ich will weg vom Stahlbau und richtig in die Zerspanung. Bei uns gibt es nur eine CNC-Maschine und keinen, der es mir richtig beibringt. Fahrzeit nach Ternitz ist ca. 35 Minuten über den Semmering, das ist für mich okay.

## Nachricht
Hallo! Ich bin Quereinsteigerin in die Zerspanung, habe aber die Lehre Metalltechnik und seit einem Jahr Praxis an der CNC-Fräse. Ich weiß, dass mir Erfahrung fehlt, aber ich lerne schnell und würde jede Schulung mitmachen. Wenn Sie jemandem eine Chance geben wollen, der wirklich will: ich bin da. LG Daniela
