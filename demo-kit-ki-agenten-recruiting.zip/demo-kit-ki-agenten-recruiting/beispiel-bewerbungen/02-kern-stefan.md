# Bewerbung: Stefan Kern

Eingegangen über: Facebook-Anzeige (Kurzbewerbung per Formular, kein Lebenslauf)
Wohnort: 2700 Wiener Neustadt
Kontakt: 0664 000 11 02 (fiktiv) · stefan.kern@example.at

## Ausbildung
- Lehre Maschinenbautechnik, Lehrabschluss 2019 (Betrieb in Wiener Neustadt)

## Berufserfahrung
- 2019 bis 2021: Maschinenbediener CNC-Fräsen, Serienfertigung Automobilzulieferer (3-Achs, Siemens Sinumerik 840D)
- 2021 bis Juli 2026: CNC-Fräser Einzelteilfertigung, Betrieb in Wiener Neustadt (3-Achs DMG MORI, Siemens 840D ShopMill, eigenständige Programmierung an der Maschine)
- Betrieb hat im Juli 2026 die Fräserei geschlossen, seitdem arbeitssuchend

## Kenntnisse
- Steuerungen: Siemens 840D / ShopMill (sehr gut), Heidenhain (noch nie gearbeitet, "lern ich gern")
- CAM: Mastercam, Grundkurs 2023, wenig Praxis
- Messtechnik: Handmessmittel, keine Messmaschine
- Staplerschein: nein
- Schweißen: MAG, Grundkenntnisse aus der Lehre
- Englisch: Schulenglisch, für Maschinenmenüs ausreichend
- Führerschein B, eigenes Auto

## Antworten aus dem Bewerbungsformular
- Zweischicht Früh/Spät: ja
- Überstunden / gelegentlich Samstag: ja
- Verfügbarkeit: sofort
- Gehaltsvorstellung: 3.400 brutto
- Warum wechseln: Meine Firma hat die Fräserei zugesperrt. Ich will wieder Einzelteile machen, keine Serie.

## Nachricht
Hallo, ich hab die Anzeige auf Facebook gesehen. 5 Jahre CNC-Fräsen, Siemens. Heidenhain hab ich noch nicht, wär aber kein Problem für mich. Bin sofort verfügbar. LG Stefan
