# Bewerbung (eingegangen per Formular Karriereseite)

Eingang: heute, 22:47 Uhr
Kanal: Meta-Kampagne → Karriereseite
Name: Martina Pichler
Wohnort: 2620 Neunkirchen
Kontakt: 0664 000 11 01 (fiktiv) · m.pichler@example.at

## Nachricht
Guten Tag, ich habe Ihre Anzeige auf Facebook gesehen. Ich arbeite seit zehn
Jahren an CNC-Fräsmaschinen, die letzten fünf auf 5-Achs Hermle mit Heidenhain.
Die Hermle C 42 bei Ihnen würde mich sehr interessieren. Ich kann gerne nach
der Arbeit auf einen Kaffee vorbeikommen.

Mit freundlichen Grüßen
Martina Pichler

## Anhang
lebenslauf-pichler.pdf
